package com.example.submission1dicoding;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MoviesAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Movies> movies = new ArrayList<>();

    public void setMovies(ArrayList<Movies> heroes) {
        this.movies = heroes;
    }

    public MoviesAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int position) {
        return movies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View itemView = view;
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.movies_item, viewGroup, false);
        }
        ViewHolder viewHolder = new ViewHolder(itemView);
        Movies movies = (Movies) getItem(position);
        viewHolder.bind(movies);
        return itemView;
    }

    private class ViewHolder {
        private TextView txtName;
        private TextView txtDescription;
        private ImageView imgPhoto;
        ViewHolder(View view) {
            txtName = view.findViewById(R.id.nama);
            txtDescription = view.findViewById(R.id.deskripsi);
            imgPhoto = view.findViewById(R.id.foto);
        }
        void bind(Movies movie) {
            txtName.setText(movie.getNama());
            txtDescription.setText(movie.getDeskripsi());
            imgPhoto.setImageResource(movie.getFoto());
        }
    }

}




