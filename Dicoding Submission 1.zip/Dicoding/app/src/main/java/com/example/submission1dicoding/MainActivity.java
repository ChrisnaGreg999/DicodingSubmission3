package com.example.submission1dicoding;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MoviesAdapter adapter;
    private String[] data_nama;
    private String[] data_diskripsi;
    private String[] data_cast;
    private String[] data_date;
    private TypedArray data_foto;

    private ArrayList<Movies> movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.movie_list);
        adapter = new MoviesAdapter(this);
        listView.setAdapter(adapter);

        prepare();
        addItem();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, movies.get(i).getNama(), Toast.LENGTH_SHORT).show();
                showSelectedMovie(movies.get(i));
            }
        });
    }

    private void showSelectedMovie(Movies movies) {

        Intent i = new Intent(MainActivity.this, DetailMovies.class);
        i.putExtra(DetailMovies.EXTRA_MOVIES,movies);
        startActivity(i);
    }

    private void prepare() {
        data_nama = getResources().getStringArray(R.array.data_name);
        data_diskripsi = getResources().getStringArray(R.array.data_description);
        data_cast = getResources().getStringArray(R.array.data_cast);
        data_date = getResources().getStringArray(R.array.data_date);
        data_foto = getResources().obtainTypedArray(R.array.data_photo);
    }

    private void addItem() {
        movies = new ArrayList<>();
        for (int i = 0; i < data_nama.length; i++) {
            Movies movie = new Movies();
            movie.setFoto(data_foto.getResourceId(i, -1));
            movie.setNama(data_nama[i]);
            movie.setCast(data_cast[i]);
            movie.setDate(data_date[i]);
            movie.setDeskripsi(data_diskripsi[i]);
            movies.add(movie);
        }
        adapter.setMovies(movies);
    }
}
